/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Tabung extends BangunRuang{
    int jari2, tinggi;

    public Tabung(int jari2, int tinggi) {
        this.jari2 = jari2;
        this.tinggi = tinggi;
    }
    
    
    @Override
    double luasPermukaan(){
        return (Math.PI*jari2*jari2*2)+(Math.PI*jari2*2*tinggi);
    }
    
    @Override
    double volume(){
        return Math.PI*jari2*jari2*tinggi;
    }
}
