/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        Scanner input = new Scanner(System.in);
        int menu, sisi, alas, panjang, lebar, tinggi, jari;
        String balik = null;
        
        do{
            System.out.print("Menu\n1.Persegi\n2.Lingkaran\n3.Persegi Panjang\n4.Segitiga\n5.Kubus\n6.Tabung\n7.Balok\n0.Exit\nPilih : ");
            //menu = input.nextInt();
            
            try {
                menu = input.nextInt();
                switch(menu){
        
                    case 1 :  
                            System.out.print("Masukkan besar sisi persegi = ");
                            sisi = input.nextInt();
                            BangunDatar persegi = new Persegi (sisi);
                            System.out.println("Luas Persegi = " + persegi.luas());
                            System.out.println("Keliling Persegi = " + persegi.keliling());
                            break;
                    case 2 :
                            System.out.print("Masukkan besar jari-jari lingkaran = ");
                            jari = input.nextInt();
                            BangunDatar lingkaran = new Lingkaran (jari);
                            System.out.println("Luas Lingkaran = " + lingkaran.luas());
                            System.out.println("Keliling Lingkaran = " + lingkaran.keliling());
                            break;
                    case 3 :
                            System.out.print("Masukkan besar alas sisi persegi panjang = ");
                            alas = input.nextInt();
                            System.out.print("Masukkan besar tinggi sisi persegi panjang = ");
                            tinggi = input.nextInt();
                            BangunDatar persegiPanjang = new PersegiPj (alas, tinggi);
                            System.out.println("Luas Persegi Panjang = " + persegiPanjang.luas());
                            System.out.println("Keliling Persegi Panjang = " + persegiPanjang.keliling());
                            break;
                    case 4 :
                                System.out.print("Masukkan besar alas sisi segitiga = ");
                            alas = input.nextInt();
                            System.out.print("Masukkan besar tinggi sisi segitiga = ");
                            tinggi = input.nextInt();
                            BangunDatar segitiga = new Segitiga (alas, tinggi);
                            System.out.println("Luas Segitiga = " + segitiga.luas());
                            break;
                    case 5 :  
                            System.out.print("Masukkan besar sisi Kubus = ");
                            sisi = input.nextInt();
                            BangunRuang kubus = new Kubus (sisi);
                            System.out.println("Luas Permukaan Kubus = " + kubus.luasPermukaan());
                            System.out.println("Keliling Kubus = " + kubus.keliling());
                            System.out.println("Volume Kubus = " + kubus.volume());
                            break;
                    case 6 :  
                            System.out.print("Masukkan besar jari-jari alas tabung = ");
                            jari = input.nextInt();
                            System.out.print("Masukkan besar tinggi tabung = ");
                            tinggi = input.nextInt();
                            BangunRuang tabung = new Tabung (jari, tinggi);
                            System.out.println("Luas Permukaan Tabung = " + tabung.luasPermukaan());
                            System.out.println("Volume Tabung = " + tabung.volume());
                            break;
                    case 7 :  
                            System.out.print("Masukkan besar panjang balok = ");
                            panjang = input.nextInt();
                            System.out.print("Masukkan besar lebar balok = ");
                            lebar = input.nextInt();
                            System.out.print("Masukkan besar tinggi tabung = ");
                            tinggi = input.nextInt();
                            BangunRuang balok = new Balok (panjang, lebar, tinggi);
                            System.out.println("Luas Permukaan Balok = " + balok.luasPermukaan());
                            System.out.println("Keliling Balok = " + balok.keliling());
                            System.out.println("Volume Balok = " + balok.volume());
                            break;
                    case 0 : 
                            break;
                    default :
                             break;
                }
                
            }
            catch (InputMismatchException error) {
            System.out.println("Nilai yang diinput harus Integer");
            }        
            finally{
                System.out.print("Balik ke menu?(y/n) = ");
                balik = input.next();
            }
        }while("y".equals(balik));
    }
    
}
