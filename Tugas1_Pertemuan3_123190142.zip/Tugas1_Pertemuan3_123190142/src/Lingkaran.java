/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Lingkaran extends BangunDatar{
    int jari2;

    public Lingkaran(int jari2) {
        this.jari2 = jari2;
    }
    
    @Override
    double luas(){
        return Math.PI*jari2*jari2;
    }
    
    @Override
    double keliling(){
        return 2*Math.PI*jari2;
    }
}
