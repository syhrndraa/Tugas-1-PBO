/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class Kubus extends BangunRuang{
    int sisi;

    public Kubus(int sisi) {
        this.sisi = sisi;
    }
    
    @Override
    double luasPermukaan(){
        return 6*sisi*sisi;
    }
    
    @Override
    double keliling(){
        return sisi*12;
    }
    
    @Override
    double volume(){
        return sisi*sisi*sisi;
    }

}
