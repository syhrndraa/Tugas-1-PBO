/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class PersegiPj extends BangunDatar{
    int alas, tinggi;

    public PersegiPj(int alas, int tinggi) {
        this.alas = alas;
        this.tinggi = tinggi;
    }
    
    @Override
    double luas(){
        return alas*tinggi;
    }
    
    @Override
    double keliling(){
        return 2*(alas+tinggi);
    }
}
